# Intel&reg; RealSense&trade; Linux SDK
## Projection Sample
---
### Description


### Category
    RealSense(TM) SDK

### Author
    Intel(R) Corporation
    
### Hardware Requirements
    zr300

### Libraries
    

### Compiler Flags
    -std=c++11

### Libraries Flags
    -lrealsense_projection -lrealsense_image -lrealsense -lopencv_imgproc -lopencv_core

### Date
    22/08/2016
    
